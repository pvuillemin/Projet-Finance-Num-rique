#pragma once
#include <vector>
#include <random>
#include <chrono>
class StochasticProcesses //A mother class for every stochastic processes
{// The programm is aim to simultate and calculate the integral of paths over a interval [0;T]
 

public:
	StochasticProcesses(void);
	~StochasticProcesses(void);
	double GetInitValue(void);
	double GetFinalValue(void);
	virtual double Scheme(double x0, double h)=0; //In order to simulate a discretisation scheme is always required
	virtual double Scheme(double x0, double h, double W)=0; //In order to simulate a discretisation scheme is always required
	virtual std::vector<double> Simul(int n, double T);//A method to simulate paths
	virtual double SimulInt(int n, double T);// A method to calculate the integral of a path over an interval

protected:
	double _initValue; //initial value of the process 
	double _finalValue; // value at the nd of the simulated path
};

