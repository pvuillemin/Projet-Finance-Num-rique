#pragma once
#include "StochasticProcesses.h"
class CoupleProcesses
{
public:// Since Stochastic processes is abstract we have to use pointers on Stochastic processes, the correlation is an input
	CoupleProcesses(StochasticProcesses* x, StochasticProcesses* y, double rho);
	~CoupleProcesses(void);
	StochasticProcesses* GetX(void);//getters for the underlying processes
	StochasticProcesses* GetY(void);
	double SimulIntSum(int n, double T);//Function which calculates the integral of the sum of the processes

private:
	StochasticProcesses* _x;
	StochasticProcesses* _y;
	double _rho;
	double _rho2;
};

