#include "CIR.h"


CIR::CIR(double k, double theta, double sigma, double initValue )
{
	_k=k;
	_theta=theta;
	_sigma=sigma;
	_initValue=initValue;
	_finalValue=0;// As a default setting the final value is set to 0, t doesn't really matter at this step
}


CIR::~CIR(void)
{
}
