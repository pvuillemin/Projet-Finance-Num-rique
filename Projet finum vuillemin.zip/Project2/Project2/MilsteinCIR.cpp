#include "MilsteinCIR.h"


MilsteinCIR::MilsteinCIR(double k, double theta, double sigma, double initValue):CIR(k,theta,sigma,initValue )
{
	_sigma2=sigma*sigma;
}


MilsteinCIR::~MilsteinCIR(void)
{
}

double MilsteinCIR::Scheme(double x0, double h)
{
	double res; // local variable to store the result
	double Wh; // local variable to store the value of the simulation of the normal distribution
// We first need to simulate a normal distribution used to simulate the diffusion part of the process
	

	//we use the mersenne twister to simulate our random variables
    std::mt19937 generator;
    generator.seed(time(0));
    std::normal_distribution<double> distribution(0,sqrt(h));
    Wh=distribution(generator); //Wh follows a normal(0,h)

	// we must respect the positivity constraint so we simulate until the value we obtained is positive

	res=x0+ _k*(_theta-x0)*h+_sigma*sqrt(x0)*Wh+_sigma2*(Wh*Wh-h)/4;

	while (res<0)// the acceptance rate is alway strictly superior to 0.5, ensuring the convergence almost surely
	{
		Wh=distribution(generator);
		res=x0+ _k*(_theta-x0)*h+_sigma*sqrt(x0)*Wh+_sigma2*(Wh*Wh-h)/4;
	}

	return res;

}


double MilsteinCIR::Scheme(double x0, double h, double W)
{// this function will be used to simulate pasth for a couple of process. The brownian motion is correlated to the one which is leading the other process and 
//cannot be included alone in this class. So W will be given by an external procedure.

	return(x0 + _k*(_theta-x0)*h+_sigma*sqrt(x0)*W+_sigma2*(W*W-h)/4); 

}
