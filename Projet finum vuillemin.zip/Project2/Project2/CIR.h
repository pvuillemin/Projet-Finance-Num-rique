#pragma once
#include "stochasticprocesses.h"
class CIR :
	public StochasticProcesses
{
public:
	CIR(double k, double theta, double sigma, double initValue );
	~CIR(void);

protected:	
	double _k;
	double _theta;
	double _sigma; 
};

