#include "StochasticProcesses.h"


StochasticProcesses::StochasticProcesses(void)
{
}


StochasticProcesses::~StochasticProcesses(void)
{
}

std::vector<double>StochasticProcesses::Simul(int n, double T)
{
std::vector<double> res;// local variable to store the result
double h= T/n; //discretization step
double xPast=_initValue; // initialisation of the past value
double xPresent; // initialisation of the last value calculated
// in order to simulate a path we use recursively the function Scheme to calculate the value neighbour to neighbour.

//initialisation:
res.push_back(_initValue);
xPresent=Scheme(xPast,h);
res.push_back(xPresent); // at this step the two first values of the process have been computed, n-1 are remaining

for (int i = 1; i < n; i++)// the loop calculates the n-1 remaining values
{
	xPast=xPresent; // the past value becomes the lattest calculated value.
	xPresent=Scheme(xPast,h);// we compute the next value
	res.push_back(xPresent);// we add it to the result
}
_finalValue=xPresent; // we store the final value of the process wich migth be useful
return res;

}


double StochasticProcesses::SimulInt(int n, double T)
{
double integral;// local variable to store the result
double h= T/n; //discretization step


// we calculate the integral interval by interval within the subdivision.

//initialisation:
double xPast=_initValue; // initialisation of the past value
double xPresent=Scheme(xPast,h); // initialisation of the last value calculated
integral=h*(xPresent+xPast)/2; //computation of the integral on the first subdivision using the Trapezoidal rule 

for (int i = 1; i < n; i++)
{
	xPast=xPresent; // the past value becomes the lattest calculated value.
	xPresent=Scheme(xPast,h);// we compute the next value
	integral=integral+h*(xPresent+xPast)/2; // we add the value of the integral of this subdivison
}

return integral;

}

double StochasticProcesses::GetInitValue(void)
{
return _initValue;
}

double StochasticProcesses::GetFinalValue(void)
{
return _finalValue;
}