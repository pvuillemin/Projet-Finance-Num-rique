#include <iostream>
#include <random>
#include "EulerCIR.h"
#include"MilsteinCIR.h"
#include"CoupleProcesses.h"
using namespace std;


int main()
{
    // Initialisation of the processes
	
	EulerCIR y(0.354201,0.00121853,0.0238186,0.0181);
	EulerCIR x(0.528905,0.0319904,0.130035,8.32349*0.00001);
	CoupleProcesses C(&x,&y,1);
	//Monte Carlo, Doesn't work because of the seed
	double sum=0;
	for (int i = 0; i < 10; i++)
	{
		sum=sum+exp(-C.SimulIntSum(500,5));
		cout << exp(-C.SimulIntSum(500,5)) << endl;
	}

	
    return 0;
}
