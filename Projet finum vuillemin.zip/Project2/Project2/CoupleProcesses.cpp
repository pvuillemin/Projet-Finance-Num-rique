#include "CoupleProcesses.h"


CoupleProcesses::CoupleProcesses(StochasticProcesses* x, StochasticProcesses* y, double rho)
{

	_x=x;
	_y=y;
	_rho=rho;
	_rho2=rho*rho;
}


CoupleProcesses::~CoupleProcesses(void)
{
}

StochasticProcesses* CoupleProcesses::GetX(void)
{
return _x;
}

StochasticProcesses* CoupleProcesses::GetY(void)
{
return _y;
}


double CoupleProcesses::SimulIntSum(int n, double T)
{

double integral;// local variable to store the result
double h= T/n; //discretization step
double W,Wprime,Z; //the brownian increments
//Initialisation

double xPast= (_x->GetInitValue()); // initialisation of the past value of x
double yPast= (_y->GetInitValue()); // initialisation of the past value of y
double xPresent=0;
double yPresent=0;
double sPast;// values of the sum of the two processes
double sPresent;

//Now we have to simulate the brownian increments.

//we use the mersenne twister to simulate our random variables	
	
    std::mt19937 generator(time(0));	
    std::normal_distribution<double> distribution(0,sqrt(h));

//To spare some simulations we have to separate the case
//|rho|=1

if (abs(_rho)==1)//Z=rho*W
{
	
    W=distribution(generator); //W follows a normal(0,h)
	Z=_rho*W;
	double xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	double yPresent=(_y->Scheme(yPast,h,Z));
}
else
{
	W=distribution(generator);//Here we have to simualte independently W and Wprime to compute Z
	Wprime=distribution(generator);
	Z=_rho*W+sqrt(1-_rho2)*Wprime;

	xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	yPresent=(_y->Scheme(yPast,h,Z));
}

//We have to ensure the positivity condition:

while ((xPresent<0)||(yPresent<0))
{
	if (abs(_rho)==1)//Z=rho*W
{
	
    W=distribution(generator); //W follows a normal(0,h)
	Z=_rho*W;
	xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	yPresent=(_y->Scheme(yPast,h,Z));
}
else
{
	W=distribution(generator);//Here we have to simualte independently W and Wprime to compute Z
	Wprime=distribution(generator);
	Z=_rho*W+sqrt(1-_rho2)*Wprime;

	xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	yPresent=(_y->Scheme(yPast,h,Z));
}
}

sPast=xPast+yPast;
sPresent=xPresent+yPresent;
integral= h*(sPast+sPresent)/2; //The integral is calculated with the trapezoidal rule



// Then we have to iterate the manoeuver

for (int i = 1; i < n; i++)
{
	xPast=xPresent;// actualisation of values
	yPast=yPresent;


	//calculation of the next values with the separation of cases and positivity condition

	if (abs(_rho)==1)//Z=rho*W
{
	
    W=distribution(generator); //W follows a normal(0,h)
	Z=_rho*W;
	xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	yPresent=(_y->Scheme(yPast,h,Z));
}
else
{
	W=distribution(generator);//Here we have to simualte independently W and Wprime to compute Z
	Wprime=distribution(generator);
	Z=_rho*W+sqrt(1-_rho2)*Wprime;

	xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	yPresent=(_y->Scheme(yPast,h,Z));
}

//We have to ensure the positivity condition:

while ((xPresent<0)||(yPresent<0))
{
	if (abs(_rho)==1)//Z=rho*W
{
	
    W=distribution(generator); //W follows a normal(0,h)
	Z=_rho*W;
	xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	yPresent=(_y->Scheme(yPast,h,Z));
}
else
{
	W=distribution(generator);//Here we have to simualte independently W and Wprime to compute Z
	Wprime=distribution(generator);
	Z=_rho*W+sqrt(1-_rho2)*Wprime;

	xPresent=(_x->Scheme(xPast,h,W));//we calculate the next values using the schemes
	yPresent=(_y->Scheme(yPast,h,Z));
}
}

sPast=xPast+yPast;
sPresent=xPresent+yPresent;
integral= integral+h*(sPast+sPresent)/2;// we add the integral on the present subdivision to the old ones


}

return integral;



}