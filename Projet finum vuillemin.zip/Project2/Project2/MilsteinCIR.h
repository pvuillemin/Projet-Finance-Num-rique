#pragma once
#include "CIR.h"
class MilsteinCIR :
	public CIR
{
public:
	MilsteinCIR(double k, double theta, double sigma, double initValue);
	~MilsteinCIR(void);
	double Scheme(double x0, double h);// Used to calculate one step of discretisation of the process alone, it starts from x0 and h is the discretization step 
	double Scheme(double x0, double h, double W);// Used to calculate the step when the brownian motion W is constrained. For example to simulate a couple of
	//processes the Brownian motion maybe correlated to the one of the other process an must be tackled outside the class.
private:
	double _sigma2;// the variance will be used at each iteration in the simulation
	//It is worth being calculated once for all.
};

