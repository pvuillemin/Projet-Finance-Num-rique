#pragma once
#include "CIR.h"

class EulerCIR : //A class for CIR processes using Euler explicit discretisation scheme
	public CIR
{
public:
	EulerCIR(double k, double theta, double sigma, double initValue );
	~EulerCIR(void);
	double Scheme(double x0, double h);// Used to calculate one step of discretisation of the process alone, it starts from x0 and h is the discretization step 
	double Scheme(double x0, double h, double W);// Used to calculate the step when the brownian motion W is constrained. For example to simulate a couple of
	//processes the Brownian motion maybe correlated to the one of the other process an must be tackled outside the class.
	

};

