#include "functions.h"
double __stdcall MySquare( BSTR a)
{
	std::string b;
	b=ConvertBSTRToMBS(a);
	if (b=="salut")
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}

