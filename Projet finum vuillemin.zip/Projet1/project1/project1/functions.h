#pragma once
#include <string> 
#include<Wtypes.h>
double __stdcall MySquare( double &  x);
double __stdcall CND(double  x ); //Normal CDF
double __stdcall StandardBarrier( BSTR TypeFlag, double S, double X, double H, double k, double T,double r, double b, double v); // Standard barrier options
std::string ConvertBSTRToMBS(BSTR bstr);
std::string ConvertWCSToMBS(const wchar_t* pstr, long wslen);
double __stdcall GBlackScholes(std::string TypeFlag, double S, double X, double T,double r, double b, double v);
double __stdcall DoubleBarrier( std::string TypeFlag, double S, double X, double L,double U, double T,double r, double b, double v,double delta1, double delta2);