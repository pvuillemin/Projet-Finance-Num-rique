#include "functions.h"

double __stdcall GBlackScholes(std::string TypeFlag, double S, double X, double T,double r, double b, double v)
{
	double d1,d2,res;
res=26041992;//value incase of wrong specification
d1 = (log(S / X) + (b + v*v / 2) * T) / (v * sqrt(T));
d2 = d1 - v * sqrt(T);

if (TypeFlag=="c")
{
	res = S * exp((b - r) * T) * CND(d1) - X * exp(-r * T) * CND(d2);
}
else if (TypeFlag=="p")
{
	res = X * exp(-r * T) * CND(-d2) - S * exp((b - r) * T) * CND(-d1);
}

return res;

}