#include "functions.h"

double __stdcall phi(double S, double T, double gamma,double H, double i, double r, double b, double v)
{

double lambda,kappa,d,v2;
v2=v*v;

lambda = (-r + gamma * b + 0.5 * gamma * (gamma - 1) * v2) * T;
d = -(log(S / H) + (b + (gamma - 0.5) * v2) * T) / (v * sqrt(T));
kappa = 2 * b / (v2) + (2 * gamma - 1);
return (exp(lambda) * pow(S,gamma) * (CND(d) - pow((i / S),kappa) * CND(d - 2 * log(i / S) / (v * sqrt(T)))));

}