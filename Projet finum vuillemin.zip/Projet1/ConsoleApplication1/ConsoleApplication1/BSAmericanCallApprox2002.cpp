#include "functions.h"

double max(double x, double y)
{
	if (x>y)
	{
		return x;
	}
	else
	{
		return y;
	}
}

double __stdcall BSAmericanCallApprox2002(double S, double X, double T,double r, double b, double v)
{
double BInfinity, B0, ht1, ht2,I1, I2,alfa1,alfa2,Beta, t1, res,v2,X2;
res=206041992;
v2=v*v;
X2=X*X;

t1 = 0.5 * (sqrt(5) - 1) * T;
if (b >= r)
{
	res = GBlackScholes("c", S, X, T, r, b, v);
}
else
{
	Beta = (1 / 2 - b / v2) + sqrt(pow((b / v2 - 1 / 2),2) + 2 * r / v2);
    BInfinity = (Beta / (Beta - 1)) * X;
    B0 = max(X, r / (r - b) * X);
    ht1 = -(b * t1 + 2 * v * sqrt(t1)) * X2  / ((BInfinity - B0) * B0);
    ht2 = -(b * T + 2 * v * sqrt(T)) * X2 / ((BInfinity - B0) * B0);
    I1 = B0 + (BInfinity - B0) * (1 - exp(ht1));
    I2 = B0 + (BInfinity - B0) * (1 - exp(ht2));
    alfa1 = (I1 - X)*pow(I1,(-Beta));
    alfa2 = (I2 - X)*pow(I2,(-Beta));

	if (S >= I2)
	{
	res= S - X;
	}
	else
	{
	res= alfa2 * pow(S, Beta) - alfa2 * phi(S, t1, Beta, I2, I2, r, b, v) \
                + phi(S, t1, 1, I2, I2, r, b, v) - phi(S, t1, 1, I1, I2, r, b, v) \
                - X * phi(S, t1, 0, I2, I2, r, b, v) + X * phi(S, t1, 0, I1, I2, r, b, v) \
                + alfa1 * phi(S, t1, Beta, I1, I2, r, b, v) - alfa1 * ksi(S, T, Beta, I1, I2, I1, t1, r, b, v) \
                + ksi(S, T, 1, I1, I2, I1, t1, r, b, v) - ksi(S, T, 1, X, I2, I1, t1, r, b, v) \
                - X * ksi(S, T, 0, I1, I2, I1, t1, r, b, v) + X * ksi(S, T, 0, X, I2, I1, t1, r, b, v);
	}
}

return res;


}