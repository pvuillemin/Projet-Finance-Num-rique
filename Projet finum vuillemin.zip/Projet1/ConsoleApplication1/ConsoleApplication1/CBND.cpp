#include "functions.h"

double __stdcall CBND(double X, double y, double rho)
{
//int i, ISs;
int  LG, NG;
double XX [10][3];
double W [10][3];
double H , k , hk, hs, BVN,Ass, asr, sn, A, b, bs, c, d, xs, rs;
const double Pi = 3.14159265358979;

W[0][0] = 0.17132449237917;
XX[0][0] = -0.932469514203152;
W[1][0] = 0.360761573048138;
XX[1][0] = -0.661209386466265;
W[2][0] = 0.46791393457269;
XX[2][0] = -0.238619186083197;

W[0][1] = 4.71753363865118*0.01;
XX[0][1] = -0.981560634246719;
W[1][1] = 0.106939325995318;
XX[1][1] = -0.904117256370475;
W[2][1] = 0.160078328543346;
XX[2][1] = -0.769902674194305;
W[3][1] = 0.203167426723066;
XX[3][1] = -0.587317954286617;
W[4][1]= 0.233492536538355;
XX[4][1] = -0.36783149899818;
W[5][1] = 0.249147045813403;
XX[5][1] = -0.125233408511469;

W[0][2] = 1.76140071391521*0.01;
XX[0][2] = -0.993128599185095;
W[1][2] = 4.06014298003869*0.01;
XX[1][2] = -0.963971927277914;
W[2][2] = 6.26720483341091*0.01;
XX[2][2] = -0.912234428251326;
W[3][2] = 8.32767415767048*0.01;
XX[3][2] = -0.839116971822219;
W[4][2] = 0.10193011981724;
XX[4][2] = -0.746331906460151;
W[5][2] = 0.118194531961518;
XX[5][2] = -0.636053680726515;
W[6][2] = 0.131688638449177;
XX[6][2] = -0.510867001950827;
W[7][2] = 0.142096109318382;
XX[7][2] = -0.37370608871542;
W[8][2] = 0.149172986472604;
XX[8][2] = -0.227785851141645;
W[9][2] = 0.152753387130726;
XX[9][2] = -7.65265211334973*0.01;

if (abs(rho)<0.3)
{
	NG=0;
	LG = 3;
}
else if (abs(rho) < 0.75)
{
	NG = 1;
    LG = 6;
}
else 
{
	NG = 2;
    LG = 10;
}

H = -X;
k = -y;
hk = H * k;
BVN = 0;

if (abs(rho) < 0.925)
{
	if (abs(rho) > 0)
	{
		hs = (H * H + k * k) / 2;
		asr = asin(rho);
		for (int i = 0; i < LG; i++)
		{
			for (int ISs = -1; ISs < 2; ISs=ISs+2)
			{
				sn = sin(asr * (ISs * XX[i][NG] + 1) / 2);
				BVN = BVN + W[i][NG] * exp((sn * hk - hs) / (1 - sn * sn));
			}
		}
		BVN = BVN * asr / (4 * Pi);
	}
	BVN = BVN + CND(-H) * CND(-k);
}
else
{
	if (rho<0)
	{
		k = -k;
		hk = -hk;
	}
	if (abs(rho)<1)
	{
		Ass = (1 - rho) * (1 + rho);
		A = sqrt(Ass);
		bs = (H - k) *(H-k);
		c = (4 - hk) / 8;
		d = (12 - hk) / 16;
		asr = -(bs / Ass + hk) / 2;
		if (asr > -100)
		{
			BVN = A * exp(asr) * (1 - c * (bs - Ass) * (1 - d * bs / 5) / 3 + c * d * Ass * Ass / 5);
		}
		if (-hk < 100)
		{
			b = sqrt(bs);
			BVN = BVN - exp(-hk / 2) * sqrt(2 * Pi) * CND(-b / A) * b * (1 - c * bs * (1 - d * bs / 5) / 3);
		}
		A=A/2;
		for (int i = 0; i < LG; i++)
		{
			for (int ISs = -1; ISs < 2; ISs=ISs+2)
			{
				xs = pow((A * (ISs * XX[i][NG] + 1)), 2);
				rs = sqrt(1 - xs);
				asr = -(bs / xs + hk) / 2;
				if (asr > -100)
				{
					BVN = BVN + A * W[i][NG] * exp(asr) * (exp(-hk * (1 - rs) / (2 * (1 + rs))) / rs - (1 + c * xs * (1 + d * xs)));
				}
			}
		}
		BVN = -BVN / (2 * Pi);
	}
	if (rho>0)
	{
		BVN = BVN + CND(-std::max(H, k));
	}
	else
	{
		BVN = -BVN;
		if (k > H)
		{
			BVN = BVN + CND(k) - CND(H);
		}
	}
}
return BVN;
}