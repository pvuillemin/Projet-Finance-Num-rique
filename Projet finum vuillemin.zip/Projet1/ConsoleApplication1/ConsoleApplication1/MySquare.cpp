#include "functions.h"
double __stdcall MySquare( double & x)
{
	return x*x;
}

