#include<iostream>
#include<string>
#include "functions.h"
using namespace std;


void main()

{
cout << StandardBarrier("cdo",100,90,95,3,0.5,0.08,0.04,0.25)<< endl;
cout <<GBlackScholes("c",100,100,1,0.09,0.05,0.25)<<endl;
cout <<phi(100,1,2,10,2,0.09,0.05,0.25)<<endl;
cout << BSAmericanCallApprox2002(100,100,1,0.09,0.04,0.25)<<endl;
cout << DoubleBarrier("co", 100, 100, 50,150, 0.25,0.1, 0.1, 0.15,0, 0)<<endl;
cout << "hey";
}
