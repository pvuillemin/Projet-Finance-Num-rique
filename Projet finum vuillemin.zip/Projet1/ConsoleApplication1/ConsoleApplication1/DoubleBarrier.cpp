#include "functions.h"
double __stdcall DoubleBarrier( std::string TypeFlag, double S, double X, double L,double U, double T,double r, double b, double v,double delta1, double delta2)
{
//Declaration of local variables
double E,F,Sum1,Sum2,d1,d2,d3,d4,mu1,mu2,mu3,OutValue,res;
//declaration of the u^2 and v^2 to avoid to reapeat the same calculation over and over

double v2=v*v;
//int n;


 F = U * exp(delta1 * T);
 E = L * exp(delta2 * T);
 Sum1 = 0;
 Sum2 = 0;

 if (TypeFlag=="co"|| TypeFlag=="ci")
 {
	 for (int n = -5; n < 6; n++)
	 {
		 d1 = (log(S * pow(U,2*n) / (X * pow(L,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         d2 = (log(S * pow(U,2*n) / (F * pow(L,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         d3 = (log(pow(L,2*n+2) / (X * S * pow(U,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         d4 = (log(pow(L,2*n+2) / (F * S * pow(U,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         mu1 = 2 * (b - delta2 - n * (delta1 - delta2)) / v2 + 1;
         mu2 = 2 * n * (delta1 - delta2) / v2;
         mu3 = 2 * (b - delta2 + n * (delta1 - delta2)) / v2 + 1;
         Sum1 = Sum1 + pow(U/L,n*mu1) * pow((L / S),mu2) * (CND(d1) - CND(d2)) - pow((pow(L,(n + 1)) / (pow(U,n) * S)),mu3) * (CND(d3) - CND(d4));
         Sum2 = Sum2 + pow(U/L,n*(mu1-2))  * pow((L / S),mu2) * (CND(d1 - v * sqrt(T)) - CND(d2 - v * sqrt(T))) - pow((pow(L,(n + 1)) / (pow(U,n) * S)),mu3-2) * (CND(d3 - v * sqrt(T)) - CND(d4 - v * sqrt(T)));
	 
	 }
	 OutValue = S * exp((b - r) * T) * Sum1 - X * exp(-r * T) * Sum2;
 }
 else if (TypeFlag=="po"|| TypeFlag=="pi")
 {
	 for (int n = -5; n < 6; n++)
	 {
		 d1 = (log(S * pow(U,2*n) / (E * pow(L,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         d2 = (log(S * pow(U,2*n) / (X * pow(L,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         d3 = (log(pow(L,2*n+2) / (E * S * pow(U,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         d4 = (log(pow(L,2*n+2) / (X * S * pow(U,2*n))) + (b + v2 / 2) * T) / (v * sqrt(T));
         mu1 = 2 * (b - delta2 - n * (delta1 - delta2)) / v2 + 1;
         mu2 = 2 * n * (delta1 - delta2) / v2;
         mu3 = 2 * (b - delta2 + n * (delta1 - delta2)) / v2 + 1;
         Sum1 = Sum1 + pow(U/L,n*mu1) * pow((L / S),mu2) * (CND(d1) - CND(d2)) - pow((pow(L,(n + 1)) / (pow(U,n) * S)),mu3) * (CND(d3) - CND(d4));
         Sum2 = Sum2 + pow(U/L,n*(mu1-2))  * pow((L / S),mu2) * pow((L / S),mu2) * (CND(d1 - v * sqrt(T)) - CND(d2 - v * sqrt(T))) - pow((pow(L,(n + 1)) / (pow(U,n) * S)),mu3-2) * (CND(d3 - v * sqrt(T)) - CND(d4 - v * sqrt(T)));
      }
	 OutValue = X * exp(-r * T) * Sum2 - S * exp((b - r) * T) * Sum1;
 }

 if (TypeFlag=="co"|| TypeFlag=="po")
 {
	 res=OutValue;
 }
 else if (TypeFlag =="ci")
 {
	 res = GBlackScholes("c", S, X, T, r, b, v) - OutValue;
 }
 else if (TypeFlag =="pi")
 {
	res=GBlackScholes("p", S, X, T, r, b, v) - OutValue;
 }
 return res;
}

