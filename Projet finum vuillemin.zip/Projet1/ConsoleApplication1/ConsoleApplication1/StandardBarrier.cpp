#include "functions.h"
// Standard barrier options
double __stdcall StandardBarrier( std::string TypeFlag, double S, double X, double H, double k, double T, double r, double b, double v)

	/* TypeFlag:      The "TypeFlag" gives you 8 different standard barrier options:
    '               1) "cdi"=Down-and-in call,    2) "cui"=Up-and-in call
    '               3) "pdi"=Down-and-in put,     4) "pui"=Up-and-in put
    '               5) "cdo"=Down-and-out call,   6) "cuo"=Up-out-in call
    '               7) "pdo"=Down-and-out put,    8) "puo"=Up-out-in put */

{
	/*declaration of variables the notations are the same in the book, execept for the A B C D E F replaced by f1,f2,f3,f4,f5,f6*/

	double mu, lambda, X1, X2, y1, y2, z, f1,f2,f3,f4,f5,f6,res; 
	double eta, phi;
	res=26041992;
	eta=1000000;
	phi=1000000;
   //expressions from page 152
	mu = (b - (v*v)/ 2) / (v*v);
    lambda = sqrt(mu*mu + 2 * r / (v*v));
    X1 = log(S / X) / (v * sqrt(T)) + (1 + mu) * v * sqrt(T);
    X2 = log(S / H) / (v * sqrt(T)) + (1 + mu) * v * sqrt(T);
    y1 = log((H*H) / (S * X)) / (v * sqrt(T)) + (1 + mu) * v * sqrt(T);
    y2 = log(H / S) / (v * sqrt(T)) + (1 + mu) * v * sqrt(T);
    z = log(H / S) / (v * sqrt(T)) + lambda * v * sqrt(T);
	
	//calibration from page 153
	if (TypeFlag=="cdi" || TypeFlag=="cdo")
	{
		eta = 1;
        phi = 1;
	}
	else if (TypeFlag=="cui" || TypeFlag=="cuo")
	{
		eta = -1;
        phi = 1;
	}
	else if (TypeFlag=="pdi" || TypeFlag=="pdo")
	{
		eta = 1;
        phi = -1;
	}
	else if (TypeFlag=="pui" || TypeFlag=="puo")
	{
		eta = -1;
        phi = -1;
	}
	
	//expressions from page 152
	f1 = phi * S * exp((b - r) * T) * CND(phi*X1) - phi*X * exp(-r*T) * CND(phi * X1 - phi * v * sqrt(T));
    f2 = phi * S * exp((b - r) * T) * CND(phi * X2) - phi * X * exp(-r * T) * CND(phi * X2 - phi * v * sqrt(T));
    f3 = phi * S * exp((b - r) * T) * pow((H / S),(2 * (mu + 1))) * CND(eta * y1) - phi * X * exp(-r * T) * pow((H / S),(2 * mu)) * CND(eta * y1 - eta * v * sqrt(T));
    f4 = phi * S * exp((b - r) * T) * pow((H / S),(2 * (mu + 1))) * CND(eta * y2) - phi * X * exp(-r * T) * pow((H / S),(2 * mu)) * CND(eta * y2 - eta * v * sqrt(T));
    f5 = k * exp(-r * T) * (CND(eta * X2 - eta * v * sqrt(T)) - pow((H / S),(2 * mu)) * CND(eta * y2 - eta * v * sqrt(T)));
    f6 = k * (pow((H / S),(mu + lambda)) * CND(eta * z) + pow((H / S),(mu - lambda)) * CND(eta * z - 2 * eta * lambda * v * sqrt(T)));

	if (X>H)
	{
		if (TypeFlag=="cdi")
		{
			res= (f3+f5);
		}
		if (TypeFlag=="cui")
		{
			res= (f1+f5);
		}
		if (TypeFlag=="pdi")
		{
			res= (f2-f3+f4+f5);
		}
		if (TypeFlag=="pui")
		{
			res= (f1-f2+f4+f5);
		}
		if (TypeFlag=="cdo")
		{
			res= (f1-f3+f6);
		}
		
		if (TypeFlag=="cuo")
		{
			res= (f6);
		}
		if (TypeFlag=="pdo")
		{
			res= (f1-f2+f3-f4+f6);
		}
		if (TypeFlag=="puo")
		{
			res= (f2-f4+f6);
		}
	}
	else if(X<H)
	{
		if (TypeFlag=="cdi")
		{
			res= (f1-f2+f4+f5);
		}
		if (TypeFlag=="cui")
		{
			res= (f2-f3+f4+f5);
		}
		if (TypeFlag=="pdi")
		{
			res= (f1+f5);
		}
		if (TypeFlag=="pui")
		{
			res= (f3+f5);
		}
		if (TypeFlag=="cdo")
		{
			res= (f2+f6-f4);
		}
		
		if (TypeFlag=="cuo")
		{
			res= (f1-f2+f3-f4+f6);
		}
		if (TypeFlag=="pdo")
		{
			res= (f6);
		}
		if (TypeFlag=="puo")
		{
			res= (f1-f3+f6);
		}
	}
	
return res;
}