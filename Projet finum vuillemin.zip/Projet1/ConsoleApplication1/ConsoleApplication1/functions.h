#pragma once
#include <string> 
#include <math.h>
double __stdcall MySquare( double &  x);
double __stdcall CND(double  x ); //Normal CDF
double __stdcall CBND(double X, double y, double rho);
double __stdcall StandardBarrier( std::string TypeFlag, double S, double X, double H, double k, double T,double r, double b, double v); // Standard barrier options
double __stdcall ksi(double S, double T2, double gamma,double H, double I2,double I1,double t1, double r, double b, double v);
double __stdcall phi(double S, double T, double gamma,double H, double i, double r, double b, double v);
double __stdcall GBlackScholes(std::string TypeFlag, double S, double X, double T,double r, double b, double v);
double __stdcall BSAmericanCallApprox2002(double S, double X, double T,double r, double b, double v);
double __stdcall DoubleBarrier( std::string TypeFlag, double S, double X, double L,double U, double T,double r, double b, double v,double delta1, double delta2);


