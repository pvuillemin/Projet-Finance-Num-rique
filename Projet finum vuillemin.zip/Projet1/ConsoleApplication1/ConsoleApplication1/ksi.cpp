
#include "functions.h"

double __stdcall ksi(double S, double T2, double gamma,double H, double I2,double I1,double t1, double r, double b, double v)
{
	double e1,e2,e3,e4,f1,f2,f3,f4,rho,kappa,lambda,res,v2;
	v2=v*v;
	e1 = (log(S / I1) + (b + (gamma - 0.5) * v2) * t1) / (v * sqrt(t1));
    e2 = (log(I2*I2 / (S * I1)) + (b + (gamma - 0.5) * v2) * t1) / (v * sqrt(t1));
    e3 = (log(S / I1) - (b + (gamma - 0.5) * v * v) * t1) / (v * sqrt(t1));
    e4 = (log(I2*I2 / (S * I1)) - (b + (gamma - 0.5) * v2) * t1) / (v * sqrt(t1));
    
    f1 = (log(S / H) + (b + (gamma - 0.5) * v2) * T2) / (v * sqrt(T2));
    f2 = (log(I2*I2 / (S * H)) + (b + (gamma - 0.5) * v) * T2) / (v * sqrt(T2));
    f3 = (log(I1*I1 / (S * H)) + (b + (gamma - 0.5) * v2) * T2) / (v * sqrt(T2));
    f4 = (log((S * I1*I1 ) / (H * I2*I2)) + (b + (gamma - 0.5) * v2) * T2) / (v * sqrt(T2));
    
    rho = sqrt(t1 / T2);
    lambda = -r + gamma * b + 0.5 * gamma * (gamma - 1) * v2;
    kappa = 2 * b / (v2) + (2 * gamma - 1);
    
    res = exp(lambda * T2) * pow(S, gamma) * (CBND(-e1, -f1, rho) - pow((I2 / S) ,kappa) * CBND(-e2, -f2, rho) - pow((I1 / S), kappa) * CBND(-e3, -f3, -rho) +pow( (I1 / I2),kappa) * CBND(-e4, -f4, -rho));

	return res;
}

